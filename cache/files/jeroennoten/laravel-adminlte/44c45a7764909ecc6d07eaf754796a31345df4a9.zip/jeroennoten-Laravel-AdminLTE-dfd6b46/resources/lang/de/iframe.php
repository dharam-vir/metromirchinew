<?php

return [

    /*
    |--------------------------------------------------------------------------
    | IFrame Mode Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the AdminLTE IFrame mode blade
    | layout. You are free to modify these language lines according to your
    | application's requirements.
    |
    */

    'btn_close' => 'Schließen',
    'btn_close_active' => 'Aktive schließen',
    'btn_close_all' => 'Alle schließen',
    'btn_close_all_other' => 'Alle anderen schließen',
    'tab_empty' => 'Kein Tab ausgewählt!',
    'tab_home' => 'Home',
    'tab_loading' => 'Tab wird geladen',

];

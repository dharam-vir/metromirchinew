<?php

return [

    'main_navigation' => 'HLAVNÁ NAVIGÁCIA',
    'blog' => 'Blog',
    'pages' => 'Stránky',
    'account_settings' => 'NASTAVENIA KONTA',
    'profile' => 'Profil',
    'change_password' => 'Zmena hesla',
    'multilevel' => 'Viac úrovňové',
    'level_one' => 'Úroveň 1',
    'level_two' => 'Úroveň 2',
    'level_three' => 'Úroveň 3',
    'labels' => 'ŠTÍTKY',
    'important' => 'Dôležité',
    'warning' => 'Varovanie',
    'information' => 'Informácie',
];

<?php

return [

    'main_navigation' => 'MENU PRINCIPALE',
    'blog' => 'Blog',
    'pages' => 'Pages',
    'account_settings' => 'PARAMÈTRES DU COMPTE',
    'profile' => 'Profil',
    'change_password' => 'Change Password',
    'multilevel' => 'Multi niveau',
    'level_one' => 'Niveau 1',
    'level_two' => 'Niveau 2',
    'level_three' => 'Niveau 3',
    'labels' => 'LABELS',
    'important' => 'Important',
    'warning' => 'Avertissement',
    'information' => 'Informations',
];
